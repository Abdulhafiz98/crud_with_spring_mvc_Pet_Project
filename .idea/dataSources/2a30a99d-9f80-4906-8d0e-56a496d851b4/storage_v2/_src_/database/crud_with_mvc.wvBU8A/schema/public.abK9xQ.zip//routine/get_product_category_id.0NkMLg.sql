create function get_product_category_id(category_id integer) returns SETOF product
    language plpgsql
as
$$BEGIN
        return query
    select product.id as id,
           product.name as name,
           product.price as price,
           product.quantity as quantity,
           product.info as info,
           product.category_id as category_id,
           product.created_by as created_by,
           product.created_date as created_date,
           product.updated_date as updated_date,
           product.product_url as product_url
    from product inner join (
        with recursive categ as
                           (select *, 1 as val
                            from category
                            where id = $1
                            union all
                            select category.*, val + 1 as val
                            from category
                                     inner join categ C
                                                on C.id = category.parent_id)
        select id
        from categ
        where val = (select max(val) from categ val)
    ) as categ on product.category_id = categ.id;
        END$$;

alter function get_product_category_id(integer) owner to postgres;

