create function add_user_problem_status(i_user_id bigint, i_problem integer) returns boolean
    language plpgsql
as
$$
    begin
        insert into user_problem_status(user_id, problem_id, state) VALUES (i_user_id,i_problem,true);
        return true;
    end;
$$;

alter function add_user_problem_status(bigint, integer) owner to postgres;

