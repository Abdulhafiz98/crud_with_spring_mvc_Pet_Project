create function add_attachment_content(i_attachment_content bytea) returns bigint
    language plpgsql
as
$$
    declare v_id bigint := null;
    begin
        insert into attachment_content(content) values (i_attachment_content) returning id into v_id;
        return v_id;
    end;

    $$;

alter function add_attachment_content(bytea) owner to postgres;

