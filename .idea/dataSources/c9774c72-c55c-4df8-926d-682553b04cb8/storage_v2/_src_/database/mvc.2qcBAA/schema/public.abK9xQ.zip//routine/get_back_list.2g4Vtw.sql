create function get_back_list(i_parent_id integer) returns SETOF mvc_category
    language plpgsql
as
$$
declare
    v_chat_id int;
begin
    select parent_id into v_chat_id from mvc_category where id = i_parent_id;
    return query select  * from mvc_category where parent_id = v_chat_id;
end;
$$;

alter function get_back_list(integer) owner to postgres;

