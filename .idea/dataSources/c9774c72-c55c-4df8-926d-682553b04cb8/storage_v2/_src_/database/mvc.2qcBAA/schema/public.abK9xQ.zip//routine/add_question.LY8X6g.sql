create function add_question(i_problem_id integer, i_question_type integer, i_orders integer, i_attachment_content bytea DEFAULT NULL::bytea, i_description character varying DEFAULT NULL::character varying, i_content_ty character varying DEFAULT NULL::character varying, i_size bigint DEFAULT NULL::bigint) returns boolean
    language plpgsql
as
$$
begin
    if i_question_type = 'TEXT' then
        insert into question(description, orders, problem_id) values (i_description, i_orders, i_problem_id);
    elsif i_question_type = 'IMAGE' then
        insert into question(attachment_id, orders, problem_id)
        values ((select add_attachment(i_attachment_content := i_attachment_content, i_content_ty := i_content_ty,
                                       i_size := i_size)),
                i_orders,
                i_problem_id);
        return true;
    end if;
    return false;
end;
$$;

alter function add_question(integer, integer, integer, bytea, varchar, varchar, bigint) owner to postgres;

