create function add_user_role(i_username character varying, i_role character varying) returns smallint
    language plpgsql
as
$$
declare
    v_user_id bigint := null;
    v_role_id int    := null;
begin
    select id into v_user_id from users where username = i_username;
    if not FOUND then
        return -1;
    end if;
    select id into v_role_id from role where name = i_role;
    if not FOUND then
        return -2;
    end if;
    insert into user_role(user_id, role_id) values (v_user_id, v_role_id);
    return 0;

    exception when others
        then return -100;
end;
$$;

alter function add_user_role(varchar, varchar) owner to postgres;

