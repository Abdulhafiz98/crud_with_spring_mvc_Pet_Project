create function add_topic(i_name character varying) returns boolean
    language plpgsql
as
$$
declare v_name varchar :=null;
begin
    select name into v_name from topic where name=i_name;
    if v_name is not null then
        return false;
    end if;

    insert into topic("name") VALUES (i_name);
    return true;
end;
$$;

alter function add_topic(varchar) owner to postgres;

