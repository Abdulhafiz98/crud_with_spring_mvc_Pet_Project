create function add_user(i_name character varying, i_username character varying, i_password character varying, i_email character varying DEFAULT NULL::character varying) returns boolean
    language plpgsql
as
$$
        declare
            v_user users := null;
        begin
            select * into v_user from users where username = i_username;
            raise notice ' %', v_user;
            if v_user.username is not null then
                raise notice ' %', 'if ni ichidamiz';
                return false;
            end if;
            insert into users(name, username, password, email) values (i_name,i_username,i_password,i_email);
            return true;
        end;
    $$;

alter function add_user(varchar, varchar, varchar, varchar) owner to postgres;

