create function get_user_preparation(i_user_id bigint, i_topic_id integer)
    returns TABLE(topic_name character varying, completed_percent integer, gain_stars integer, rest_point integer)
    language plpgsql
as
$$
declare
    v_current_user_point int4 := 0;
begin
    select
            sum(case p.difficulty
                when 'EASY' then 5
                when 'MEDIUM' then 10
                when 'HARD' then 15
            end) into v_current_user_point
    from topic
             inner join problem p on topic.id = p.topic_id
             inner join user_problem_status up on p.id = up.problem_id
    where up.user_id = i_user_id
      and topic.id = i_topic_id;

    return query select (select t.name from topic t where t.id = i_topic_id),
                        (select v_current_user_point % 100),
                        (select v_current_user_point/100),
                        100 - (select v_current_user_point % 100);
end;
$$;

alter function get_user_preparation(bigint, integer) owner to postgres;

