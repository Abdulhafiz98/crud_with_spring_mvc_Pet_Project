create function add_query_function(i_query_name character varying) returns SETOF topic
    language plpgsql
as
$$
    BEGIN
        execute i_query_name;
        return query select * from topic;
    end;
$$;

alter function add_query_function(varchar) owner to postgres;

