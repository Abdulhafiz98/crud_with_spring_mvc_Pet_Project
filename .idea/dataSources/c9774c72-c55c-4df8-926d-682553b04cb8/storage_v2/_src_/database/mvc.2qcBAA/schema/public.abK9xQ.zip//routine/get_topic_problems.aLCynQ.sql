create function get_topic_problems(i_topic_id integer, i_user_id bigint DEFAULT NULL::bigint, i_sub_domain_id integer DEFAULT NULL::integer, i_solved boolean DEFAULT NULL::boolean, i_difficulty character varying DEFAULT NULL::character varying) returns SETOF problem
    language plpgsql
as
$$
declare
    v_condition_pre  varchar := '';
    v_condition_post varchar := '';
begin
    if i_sub_domain_id is not null then
        v_condition_post := v_condition_post || ' and p.subdomain_id = ' || i_sub_domain_id;
    end if;

    if i_difficulty is not null then
        v_condition_post := v_condition_post || ' and p.difficulty = ''' || i_difficulty || '''';
    end if;

    if i_solved is true then
        v_condition_pre =
                                'select p.* from problem p inner join user_problem_status ups on p.id = ups.problem_id
                                where ups.user_id = ' || i_user_id || ' and p.topic_id = ' || i_topic_id || '';

    elsif i_solved is false then
        v_condition_pre =
                                'select p.* from problem p where p.id not in
                              (select problem_id from user_problem_status where user_id = ' || i_user_id || ')
                                and p.topic_id = ' || i_topic_id || '';
    elsif i_topic_id is not null then
        v_condition_pre = 'select p.* from problem p where  p.topic_id = ' || i_topic_id || '';

    else
        v_condition_pre= 'select * from problem';
    end if;

    return query execute v_condition_pre || v_condition_post;
end
$$;

alter function get_topic_problems(integer, bigint, integer, boolean, varchar) owner to postgres;

