create function get_topic() returns SETOF topic
    language plpgsql
as
$$
begin
    return query select * from topic;
end;

$$;

alter function get_topic() owner to postgres;

