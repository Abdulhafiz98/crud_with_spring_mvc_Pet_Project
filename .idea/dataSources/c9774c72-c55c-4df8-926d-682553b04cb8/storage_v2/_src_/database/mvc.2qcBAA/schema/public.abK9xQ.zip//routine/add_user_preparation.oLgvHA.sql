create function add_user_preparation(i_topic_id integer, i_user_id integer) returns boolean
    language plpgsql
as
$$
begin
    insert into user_preparation(topic_id, user_id) values (i_topic_id, i_user_id);
    return true;
end;
$$;

alter function add_user_preparation(integer, integer) owner to postgres;

