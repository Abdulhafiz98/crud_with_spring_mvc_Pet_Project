create function get_category_list(i_parent_id integer DEFAULT 0) returns SETOF mvc_category
    language plpgsql
as
$$
begin
    if i_parent_id = 0 then
        return query select * from mvc_category where parent_id = 0;
    else
        return query select c2.* from mvc_category c
                                          join mvc_category c2 on c.id = c2.parent_id  where c2.parent_id = i_parent_id;
    end if;
end;
$$;

alter function get_category_list(integer) owner to postgres;

