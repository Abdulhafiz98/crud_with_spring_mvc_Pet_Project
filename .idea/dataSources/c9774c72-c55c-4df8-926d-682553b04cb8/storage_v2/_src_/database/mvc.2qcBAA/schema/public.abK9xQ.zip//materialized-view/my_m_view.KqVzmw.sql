create materialized view my_m_view as
SELECT users.id,
       users.first_name,
       users.last_name,
       users.username,
       users.password,
       users.age
FROM users;

alter materialized view my_m_view owner to postgres;

