create function get_product(i_category_id integer, i_page_count integer) returns SETOF product_1
    language plpgsql
as
$$
begin
    if i_page_count <= 0 then
        i_page_count = 1;
    end if;
    return query select * from product_1 where category_id = i_category_id offset i_page_count * 3 - 3  limit 3;
end;
$$;

alter function get_product(integer, integer) owner to postgres;

