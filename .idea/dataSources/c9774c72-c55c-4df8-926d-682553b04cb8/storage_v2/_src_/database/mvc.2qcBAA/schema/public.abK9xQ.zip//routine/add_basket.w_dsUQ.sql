create function add_basket(i_user integer, i_product integer) returns void
    language plpgsql
as
$$
    declare
        v_exist int :=null;
    BEGIN
       select id into v_exist from basket where taken=false and productid=i_product and userid=i_user;

       if v_exist is not null then
           update basket set taken=true where productid=i_product and userid=i_user;
        else
          insert into basket (userid, productid, taken) VALUES (i_user,i_product,true);
       end if;
end
$$;

alter function add_basket(integer, integer) owner to postgres;

