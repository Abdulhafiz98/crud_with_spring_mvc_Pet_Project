create function add_problem(i_name character varying, i_difficulty character varying, i_subdomain_id integer, i_topic_id integer) returns boolean
    language plpgsql
as
$$
    declare v_name character :=null;
    begin
        select name into v_name from problem where name = i_name;
        if v_name is not null
            then return false;
            end if;
        insert into problem(name,difficulty,subdomain_id ,topic_id) values (i_name,i_difficulty,i_subdomain_id ,i_topic_id);
        return true;
    end;

    $$;

alter function add_problem(varchar, varchar, integer, integer) owner to postgres;

