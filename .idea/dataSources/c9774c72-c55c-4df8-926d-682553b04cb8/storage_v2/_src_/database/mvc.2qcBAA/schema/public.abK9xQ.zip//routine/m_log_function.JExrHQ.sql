create function m_log_function() returns trigger
    language plpgsql
as
$$
BEGIN
   refresh materialized view  my_m_view;
   insert into new_log(tg_op_name, old_data, new_data,modifiedby) values (tg_op,to_json(old), to_json(new),1);
   return null;
end;
$$;

alter function m_log_function() owner to postgres;

