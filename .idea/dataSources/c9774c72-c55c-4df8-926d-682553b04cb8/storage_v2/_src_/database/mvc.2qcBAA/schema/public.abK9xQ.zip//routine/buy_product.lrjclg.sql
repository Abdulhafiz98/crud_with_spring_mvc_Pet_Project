create function buy_product(i_chat_id bigint, i_product_id integer) returns boolean
    language plpgsql
as
$$
declare
    v_user_id bigint;
    v_product_id int default 0;
begin
    select id into v_user_id from mvc_user where chat_id = i_chat_id;
    if v_product_id = 0 then
        insert into mvc_ordertible( userdi, product) values (v_user_id, i_product_id);
        return true;
    end if;
    return false;
end;
$$;

alter function buy_product(bigint, integer) owner to postgres;

