create function laptop_with_brand()
    returns TABLE(id integer, name character varying, madel character varying, price double precision, brand_name character varying)
    language plpgsql
as
$$
begin
    return query select l.id, l.name, l.madel, l.price, b.name
                 from laptop1 l
                          inner join brand b on b.id = l.brand_id;
end;
$$;

alter function laptop_with_brand() owner to postgres;

