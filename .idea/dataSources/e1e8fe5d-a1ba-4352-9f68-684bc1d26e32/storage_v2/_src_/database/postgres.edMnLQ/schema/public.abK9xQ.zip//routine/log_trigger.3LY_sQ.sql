create function log_trigger() returns trigger
    language plpgsql
as
$$
    begin
if tg_op ='INSERT' then
        insert into  log(changes, changet_time) VALUES (new || ' '|| 'Insert', now());
        return new;
        elsif tg_op = 'UPDATE' then
            insert into  log(changes, changet_time) VALUES (new || ' '|| 'Update', now());
            return new;
        else
            insert into  log(changes, changet_time) VALUES (new || ' '|| 'Delete', now());
            return new;
        end if;
    end;
    $$;

alter function log_trigger() owner to postgres;

