create function update_pc() returns boolean
    language plpgsql
as
$$
    begin
       update  pc set price= (price*0.9)
        where price in (select p.price from pc p order by p.price desc limit 3);
       return true;

    end;
    $$;

alter function update_pc() owner to postgres;

