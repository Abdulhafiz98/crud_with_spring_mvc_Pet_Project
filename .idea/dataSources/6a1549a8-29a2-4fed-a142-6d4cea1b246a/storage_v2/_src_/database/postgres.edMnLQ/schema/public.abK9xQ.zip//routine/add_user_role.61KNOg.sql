create function add_user_role(i_user_id integer, i_role_id integer) returns boolean
    language plpgsql
as
$$
    BEGIN
      if i_user_id is not null and i_role_id is not  null then
          insert into user_roles (user_id, role_id) values (i_user_id,i_role_id);
          return true;
      end if;
      return false;
    end
$$;

alter function add_user_role(integer, integer) owner to postgres;

