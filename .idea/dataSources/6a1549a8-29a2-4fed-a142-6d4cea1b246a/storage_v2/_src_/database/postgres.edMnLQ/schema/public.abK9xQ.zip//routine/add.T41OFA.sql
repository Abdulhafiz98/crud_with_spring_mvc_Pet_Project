create function add(i_name character varying, i_username character varying, i_password character varying) returns boolean
    language plpgsql
as
$$
    declare
        v_username character varying := null;
BEGIN
        select username into v_username from  users u where u.username=i_username;

        if v_username is not null then
            return false;
        end if;

        insert into users(name,username, password) values(i_name, i_username, i_password);
        return true;
end $$;

alter function add(varchar, varchar, varchar) owner to postgres;

