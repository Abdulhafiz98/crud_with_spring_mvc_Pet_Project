create function show_all(i_username character varying)
    returns TABLE(role_name character varying)
    language plpgsql
as
$$
declare v_user_uid int:= null;
        v_name character varying;
BEGIN
    select id into v_user_uid from users where users.username=i_username;
    select name into v_name from users where users.username=i_username;
    return query select v_name union all select name   from role1 where id in(
        select role_id from user_roles where user_id=v_user_uid
    );
end;
$$;

alter function show_all(varchar) owner to postgres;

