create function add_role(i_name character varying) returns boolean
    language plpgsql
as
$$
    declare
        v_name_in_role character varying:=null;
BEGIN
       select name into  v_name_in_role from role1 r where r.name=i_name;

       if v_name_in_role is not null then
           return  false;
       end if;

       insert into role1(name) values (i_name);
       return true;
end
$$;

alter function add_role(varchar) owner to postgres;

