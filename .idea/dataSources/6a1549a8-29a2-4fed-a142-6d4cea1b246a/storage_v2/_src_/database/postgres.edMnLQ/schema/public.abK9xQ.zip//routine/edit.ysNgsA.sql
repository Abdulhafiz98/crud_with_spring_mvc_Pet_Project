create function edit(i_id integer, i_name character varying, i_username character varying, i_password character varying) returns boolean
    language plpgsql
as
$$
    declare
        v_id int:=null;

    BEGIN
        select  id into v_id from users u where u.id=i_id;

        if v_id is null then
            return false;
        end if;

        if  i_name is not null then
            update users
            set name=i_name
            where users.id=i_id;
        end if ;

        if i_username is not null then
            update  users
            set username=i_username
            where id=i_id;
        end if;

        if i_password is not null then
            update  users
            set password=i_password
            where id=i_id;
        end if;
        return  true;
        end
      $$;

alter function edit(integer, varchar, varchar, varchar) owner to postgres;

