create function add(i_name text) returns boolean
    language plpgsql
as
$$
    begin
        insert into productnow (name) values (i_name);
        return true;
        end ;
$$;

alter function add(text) owner to postgres;

