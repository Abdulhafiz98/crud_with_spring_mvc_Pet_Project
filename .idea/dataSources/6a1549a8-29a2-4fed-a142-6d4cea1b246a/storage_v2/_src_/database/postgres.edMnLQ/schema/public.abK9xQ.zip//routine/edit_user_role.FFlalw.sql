create function edit_user_role(i_user_id integer, i_role_id integer) returns boolean
    language plpgsql
as
$$
    declare v_id int=null;
    BEGIN
        select user_id into v_id from user_roles where user_id=i_user_id;
        if v_id is null then
            return false;
            end if ;
        update user_roles
        set role_id=i_role_id
        where user_id=i_user_id;
        return true;
        end
$$;

alter function edit_user_role(integer, integer) owner to postgres;

