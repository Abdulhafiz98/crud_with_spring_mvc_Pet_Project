create function add_product_to_online_dars1(i_company character varying, i_model character varying, i_type character varying) returns void
    language plpgsql
as
$$
    declare
        sana int :=0;
        message1 character varying;
    BEGIN
    select count(model) into sana from online_dars1 where model=i_model;
    if sana=0 then
        insert into online_dars1(company, model, type) values (i_company,i_model,i_type);
        message1='mahsulot  qoshildi';
        raise notice 'aaaaa%',message1;
        else
        message1=i_model ||'mahsulot qo'shilmadi;
        raise notice 'bbbbbb%',message1;
    end if;
        end
    $$;

alter function add_product_to_online_dars1(varchar, varchar, varchar) owner to postgres;

