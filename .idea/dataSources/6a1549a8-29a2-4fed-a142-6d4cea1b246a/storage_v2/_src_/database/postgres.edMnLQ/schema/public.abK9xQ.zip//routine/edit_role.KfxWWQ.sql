create function edit_role(i_id integer, i_name character varying) returns boolean
    language plpgsql
as
$$
    declare
        v_id int:=null;
    BEGIN
        select  id into v_id from role1 r where r.id=i_id;

        if v_id is null then
            return false;
        end if;

        update role1
        set name=i_name
        where id=i_id;
        return true;
        end
      $$;

alter function edit_role(integer, varchar) owner to postgres;

