create function checkuser(i_email character varying) returns boolean
    language plpgsql
as
$$
    declare
        v varchar:=null;
    BEGIN
        select email into v from servlet_user  where email=i_email;
        if v is not null then
            return true;
        end if;
        return false;
        end $$;

alter function checkuser(varchar) owner to postgres;

