create function showinscreanwith_off(i_page bigint, i_page_length bigint DEFAULT 10, i_id bigint DEFAULT NULL::bigint, i_jobtile character varying DEFAULT NULL::character varying, i_email character varying DEFAULT NULL::character varying, i_fisrtname character varying DEFAULT NULL::character varying, i_country character varying DEFAULT NULL::character varying) returns SETOF mockdata
    language plpgsql
as
$$
declare
    v_condition character varying := '';
    v_first INTEGER:=5;
    v_end INTEGER:=5;
    begin
    if i_id is not null then

        v_condition := v_condition || ' and id = ' || '''' || i_id::int8  || '''';

    end if;

    if i_jobtile is not null then
        v_condition := v_condition || ' and jobtitle ilike ''%' || i_jobtile ||'%''';
    end if;

    if i_email is not null then
        v_condition := v_condition || ' and emailaddress ilike ''%' || i_email || '%''';
    end if;

    if i_fisrtname is not null then
        v_condition := v_condition || ' and fisrtnamelastname ilike ''%' || i_fisrtname || '%''';
    end if;

    if i_country is not null then
        v_condition := v_condition || ' and country ilike ''%' || i_country || '%''';
    end if;
--     v_condition:=v_condition || '  OFFSET ' || v_first || 'LIMIT ' || v_end;
--     return query execute 'select * from mockdata where 1 = 1' || v_condition || '  OFFSET ' || v_first || ' LIMIT ' || v_end;
    return query execute 'select * from mockdata where 1 = 1' || v_condition || ' offset ' ||
                         (i_page * i_page_length) - i_page_length || ' limit ' || i_page_length;
end
$$;

alter function showinscreanwith_off(bigint, bigint, bigint, varchar, varchar, varchar, varchar) owner to postgres;

