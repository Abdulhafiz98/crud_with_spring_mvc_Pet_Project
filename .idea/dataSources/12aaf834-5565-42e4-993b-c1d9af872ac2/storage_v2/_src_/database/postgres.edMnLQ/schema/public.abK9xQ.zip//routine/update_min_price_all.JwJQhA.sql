create function update_min_price_all() returns boolean
    language plpgsql
as
$$
    begin
       update  pc set price= (price*1.05)
        where price = (select p.price from pc p order by p.price  limit 1);
       update  laptop set price= (price*1.05)
       where price = (select l.price from laptop l order by l.price  limit 1);
       update  printer set price= (price*1.05)
       where price = (select printer.price from printer  order by printer.price  limit 1);
       return true;

    end;
    $$;

alter function update_min_price_all() owner to postgres;

