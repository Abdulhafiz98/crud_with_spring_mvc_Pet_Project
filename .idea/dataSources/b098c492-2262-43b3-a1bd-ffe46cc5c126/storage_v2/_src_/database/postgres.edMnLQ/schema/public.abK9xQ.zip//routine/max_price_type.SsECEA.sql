create function max_price_type() returns character varying
    language plpgsql
as
$$
declare
    v_type varchar := null;
begin
  select aaaa.type into v_type from (select pr.type, pr.model, p.price
     from product pr
              inner join pc p on pr.model = p.model
     union all
     select pr.type, pr.model, l.price
     from product pr
              inner join laptop l on l.model = pr.model
     union all
     select pr.type, pr.model, p2.price
     from product pr
              inner join printer p2 on p2.model = pr.model
     order by price desc
     limit 1) as aaaa;

    return v_type;
end;
$$;

alter function max_price_type() owner to postgres;

