create function avg_printer() returns integer
    language plpgsql
as
$$
    declare avg_price integer:=null;
    begin
        select avg(price) into  avg_price from printer;
        return avg_price;
    end;
    $$;

alter function avg_printer() owner to postgres;

