create function type() returns character varying
    language plpgsql
as
$$
    declare v_type varchar:=null;
    begin
        select type into  v_type from product;
        return v_type;
    end;
    $$;

alter function type() owner to postgres;

