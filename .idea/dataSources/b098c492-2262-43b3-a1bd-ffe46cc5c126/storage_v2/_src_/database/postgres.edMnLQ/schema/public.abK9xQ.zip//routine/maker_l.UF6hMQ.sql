create function maker_l() returns character varying
    language plpgsql
as
$$
    declare v_maker varchar:=null;
    begin
      select  pr.maker into v_maker from product pr
        inner join laptop l on pr.model = l.model
        order by l.price limit 1;
      if v_maker is not null
          then return v_maker;
          end if;
    end;
    $$;

alter function maker_l() owner to postgres;

